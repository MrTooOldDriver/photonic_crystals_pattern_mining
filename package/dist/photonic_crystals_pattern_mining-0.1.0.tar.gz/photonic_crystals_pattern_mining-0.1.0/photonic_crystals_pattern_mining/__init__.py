__all__ = ["IRCS_CANNY_TSNE", "IRCS_cv_locator_new_data_temporal", 
           "IRCS_cv_locator_new_data", "IRCS_cv_locator", "IRCS_HOG_TSNE", 
           "IRCS_SIFT_PATTERN_ALIGNMENT", "IRCS_SIFT_PATTERN_DENSITY_MAP", 
           "IRCS_SIFT_PATTERN", "IRCS_SIFT_TSNE"]